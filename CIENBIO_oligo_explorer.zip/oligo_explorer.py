import sys
import os
from Bio import SeqIO
from Bio.Seq import Seq
from Bio import AlignIO
from Bio.Data import CodonTable
import subprocess
import tempfile
import pandas as pd
import math
import itertools
from datetime import datetime

muscle_path = r"C:\Users\usuario\OneDrive\Documentos\CIENBIO SpA\Investigación\muscle-win64.v5.3.exe"
umbral_identidad = 50
umbral_conservacion_local = 0.85
Na_conc = 0.05

nn_values = {
    "AA": (-7.9, -22.2), "TT": (-7.9, -22.2), "AT": (-7.2, -20.4), "TA": (-7.2, -21.3),
    "CA": (-8.5, -22.7), "TG": (-8.5, -22.7), "GT": (-8.4, -22.4), "AC": (-8.4, -22.4),
    "CT": (-7.8, -21.0), "AG": (-7.8, -21.0), "GA": (-8.2, -22.2), "TC": (-8.2, -22.2),
    "CG": (-10.6, -27.2), "GC": (-9.8, -24.4), "GG": (-8.0, -19.9), "CC": (-8.0, -19.9)
}

def alinear_muscle(fasta_path):
    aligned_path = tempfile.NamedTemporaryFile(delete=False, suffix=".aln").name
    subprocess.run([muscle_path, "-align", fasta_path, "-output", aligned_path], check=True)
    return aligned_path

def calcular_identidad_global(alignment):
    total_id = 0
    total_positions = 0
    nseqs = len(alignment)
    for i in range(alignment.get_alignment_length()):
        columna = [record.seq[i] for record in alignment]
        if '-' in columna:
            continue
        max_id = max(columna.count(res) for res in set(columna))
        identidad_col = max_id / nseqs
        total_id += identidad_col
        total_positions += 1
    return (total_id / total_positions) * 100 if total_positions else 0

def calcular_conservacion_columnas(alignment):
    conservacion = []
    n = len(alignment)
    for i in range(alignment.get_alignment_length()):
        columna = [record.seq[i] for record in alignment]
        if '-' in columna:
            conservacion.append(0.0)
        else:
            max_id = max(columna.count(aa) for aa in set(columna))
            conservacion.append(max_id / n)
    return conservacion

def calcular_consenso_con_criterio(alignment, umbral):
    consenso = ''
    for i in range(alignment.get_alignment_length()):
        columna = [record.seq[i] for record in alignment]
        aa_frecuente = max(set(columna), key=columna.count)
        if columna.count(aa_frecuente) / len(columna) >= umbral:
            consenso += aa_frecuente
        else:
            consenso += '-'
    return consenso

def codones_por_aminoacido(aa_block):
    tabla = CodonTable.unambiguous_dna_by_name["Standard"]
    lista_codones = []
    for aa in aa_block:
        cods = tabla.back_table.get(aa, ["NNN"])
        lista_codones.append(cods if isinstance(cods, list) else [cods])
    return lista_codones

def calcular_tm_dg_santalucia(seq, Na=0.05):
    seq = seq.upper()
    total_dh = 0.0
    total_ds = 0.0
    for i in range(len(seq)-1):
        pair = seq[i:i+2]
        if pair in nn_values:
            dh, ds = nn_values[pair]
            total_dh += dh
            total_ds += ds
    if seq[0] in "GC":
        total_dh += 0.1
        total_ds += -2.8
    if seq[-1] in "GC":
        total_dh += 0.1
        total_ds += -2.8
    salt_correction = 16.6 * math.log10(Na)
    R = 1.987
    tm_kelvin = (1000 * total_dh) / (total_ds + (R * math.log(1e-7)))
    return round(tm_kelvin - 273.15 + salt_correction, 2), round(total_dh, 2)

fasta_input = input("📂 Ruta archivo FASTA: ").strip('"')
bloque_longitud = int(input("🔢 Longitud del bloque (ej. 5): "))

if not os.path.exists(fasta_input):
    print(f"❌ El archivo '{fasta_input}' no existe.")
    sys.exit(1)

aligned_file = alinear_muscle(fasta_input)
alignment = AlignIO.read(aligned_file, "fasta")
print("🧬 Alineamiento generado:\n")
for record in alignment:
    print(f">{record.id}\n{record.seq}\n")

identidad = calcular_identidad_global(alignment)
print(f"🔬 Identidad global promedio: {identidad:.2f}%")
if identidad < umbral_identidad:
    print(f"⚠️ Identidad insuficiente (< {umbral_identidad}%).")
    sys.exit()

print("📊 Calculando conservación...")
conservacion = calcular_conservacion_columnas(alignment)
pd.DataFrame({
    "Posición": list(range(1, len(conservacion)+1)),
    "Conservación (%)": [round(c*100, 2) for c in conservacion]
}).to_excel("conservacion_columnas.xlsx", index=False)

print("🔍 Generando partidores posibles por bloque conservado...")
consenso = calcular_consenso_con_criterio(alignment, umbral_conservacion_local)

oligos = []
for i in range(0, len(consenso) - bloque_longitud + 1):
    bloque = consenso[i:i+bloque_longitud]
    if '-' not in bloque:
        codon_list = codones_por_aminoacido(bloque)
        for comb in itertools.product(*codon_list):
            oligo = ''.join(comb)
            oligo_rc = str(Seq(oligo).reverse_complement())
            tm, dh = calcular_tm_dg_santalucia(oligo, Na=Na_conc)
            oligos.append({
                "Posición": f"{i+1}-{i+bloque_longitud}",
                "Aminoácidos": bloque,
                "Oligo Forward": oligo,
                "Oligo Reverso": oligo_rc,
                "Tm (°C)": tm,
                "ΔH (kcal/mol)": dh
            })

if oligos:
    filename = f"oligos_todos_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    pd.DataFrame(oligos).to_excel(filename, index=False)
    print(f"✅ Generado archivo: {filename}")
else:
    print("⚠️ No se generaron partidores.")
