# CIENBIO Oligo Explorer

Diseño de partidores degenerados a partir de alineamientos proteicos.
